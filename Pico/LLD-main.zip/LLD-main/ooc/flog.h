#pragma once

#include "log.h"

int filelog_create(logger *impl, char *filename);
