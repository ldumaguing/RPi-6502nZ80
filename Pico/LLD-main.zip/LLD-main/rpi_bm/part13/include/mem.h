#pragma once

#include "common.h"

void *memcpy(void *dest, const void *src, u32 n);
