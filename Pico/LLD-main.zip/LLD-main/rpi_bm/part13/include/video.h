#pragma once

#include "common.h"

bool video_set_resolution(u32 x, u32 y, u32 bpp);
